# SVT App

Flutter-based Car Rental / Taxi Billing App.

## Features
- Sedan ₹20/km
- SUV ₹22/km
- Customer name and WhatsApp number
- Pickup and drop
- Distance calculation
- Automatic bill total
- WhatsApp bill sharing

## Run
flutter pub get
flutter run

## Planned
- PDF invoice
- Bill history
- Custom rates
- Driver details
- Trip date/time
- Admin settings
